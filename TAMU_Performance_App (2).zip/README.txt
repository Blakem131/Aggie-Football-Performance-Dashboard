TEXAS A&M FOOTBALL PERFORMANCE DASHBOARD — APP PACKAGE
=======================================================

WHAT'S IN THIS FOLDER
  index.html            the dashboard (fully self-contained)
  manifest.webmanifest  app identity: name, icon, colors
  sw.js                 offline support (service worker)
  icon-192.png / icon-512.png   app icons

OPTION 1 — JUST USE IT (no install)
  Double-click index.html. Everything works, including Excel import.
  Needs internet only on the very first open (to fetch the chart library).

OPTION 2 — INSTALL AS AN APP (own icon, own window, works offline)
  The install button only appears when the page is served by a web server
  (a browser security rule), so pick either:

  A) Local, no hosting needed:
     1. Open a terminal/command prompt in this folder
     2. Run:  python -m http.server 8080
        (or:  npx serve)
     3. Visit http://localhost:8080 in Chrome or Edge
     4. Click the install icon in the address bar (monitor with down-arrow)
     -> The app now lives in your Start Menu / Applications with the A&M icon,
        opens in its own window, and works fully offline afterward.

  B) Host it (best for sharing with staff):
     Upload this folder to any static host — GitHub Pages, Netlify,
     or a Texas A&M web space. Anyone who visits can click Install.
     On iPhone/iPad: open in Safari -> Share -> Add to Home Screen.

NOTES
  - Your Excel master file stays wherever you keep it; import it into the
    app exactly as before. Nothing is uploaded anywhere.
  - To ship an update, replace index.html and bump the version string
    inside sw.js (CACHE = 'tamu-perf-v2') so installed copies refresh.
