#!/bin/bash
cd "$(dirname "$0")"
echo "Starting local server... keep this window open."
open "http://localhost:8080"
python3 -m http.server 8080
