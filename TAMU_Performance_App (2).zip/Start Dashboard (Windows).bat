@echo off
cd /d "%~dp0"
echo.
echo  ============================================================
echo   TEXAS A&M PERFORMANCE DASHBOARD
echo   Starting local server... KEEP THIS WINDOW OPEN.
echo   Your browser will open to http://localhost:8080
echo   If it doesn't, open Chrome or Edge and go there manually.
echo  ============================================================
echo.
start "" "http://localhost:8080"
py -m http.server 8080 2>nul || python -m http.server 8080 2>nul || (
  echo.
  echo  Python was not found on this computer.
  echo  Install it free from the Microsoft Store: search "Python 3.12",
  echo  then double-click this file again.
  echo.
  pause
)
